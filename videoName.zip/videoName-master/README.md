# videoName
video play background showing thought name/text
